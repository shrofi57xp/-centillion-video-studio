import os, re, uuid, asyncio, subprocess
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from PIL import Image, ImageDraw, ImageFont
import imageio_ffmpeg

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / "uploads"
OUTPUT = BASE / "output"
UPLOADS.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)
FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
app = FastAPI(title="Centillion Video Studio")

HTML = r"""<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Centillion Video Studio</title><style>
*{box-sizing:border-box}body{margin:0;background:#0b1020;color:#f2f5fa;font-family:system-ui,Arial}.wrap{max-width:850px;margin:auto;padding:16px}.hero{padding:22px 3px}.badge{color:#59e1bf;border:1px solid #38695f;border-radius:20px;padding:5px 10px;font-size:12px}h1{font-size:clamp(28px,6vw,42px)}p,.note{color:#aebbd0;line-height:1.8}.panel{background:#151d31;border:1px solid #2a3650;border-radius:18px;padding:17px;margin:14px 0}label{display:block;margin:13px 0 7px;font-weight:700}textarea,input,select{width:100%;padding:12px;border-radius:10px;border:1px solid #2a3650;background:#0c1426;color:white;font:inherit}textarea{min-height:125px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.btn{width:100%;padding:14px;margin-top:16px;border:0;border-radius:11px;background:#59e1bf;color:#06231c;font-weight:900;font:inherit}.tabs{display:flex;gap:8px}.tab{padding:11px;border:1px solid #2a3650;background:#10182a;color:white;border-radius:10px}.active{background:#59e1bf;color:#071b18}.hidden{display:none}.warn{background:#342b19;border:1px solid #735b2b;border-radius:10px;padding:12px;color:#ffe2a4;font-size:13px;line-height:1.7}.result{display:none;background:#0d2b27;border-radius:10px;padding:13px;margin-top:12px;line-height:1.8}.result a{color:#59e1bf}.status{white-space:pre-wrap;color:#aebbd0;margin-top:10px}@media(max-width:580px){.grid{grid-template-columns:1fr}}
</style></head><body><main class="wrap"><header class="hero"><span class="badge">نسخة مبسطة قابلة للنشر</span><h1>🎬 Centillion Video Studio</h1><p>إنشاء فيديو MP4 من وصف نصي أو تعديل فيديو موجود، من تلفونك أو الكمبيوتر.</p></header>
<div class="warn">تنبيه: إنشاء الفيديو النصي هنا ينتج بطاقات تصميمية مع تعليق صوتي آلي عند توفر الاتصال، وليس مشاهد سينمائية واقعية. توليد مشاهد AI واقعية يحتاج محركاً خارجياً قد يكون مدفوعاً. الملفات على الاستضافة المجانية قد تكون مؤقتة.</div>
<div class="tabs"><button class="tab active" onclick="tab('gen',this)">✨ إنشاء فيديو</button><button class="tab" onclick="tab('edit',this)">✂️ تعديل فيديو</button></div>
<section id="gen" class="panel"><h2>إنشاء فيديو</h2><label>وصف الفيديو</label><textarea id="prompt" placeholder="مثال: إعلان كاميرا مراقبة باللهجة السودانية، يبدأ بسؤال جذاب ثم يذكر الفوائد..."></textarea>
<div class="grid"><div><label>المدة</label><select id="duration"><option>10</option><option selected>20</option><option>30</option><option>45</option><option>60</option></select></div><div><label>المقاس</label><select id="aspect"><option value="vertical">عمودي 9:16 — ريلز</option><option value="horizontal">أفقي 16:9 — يوتيوب</option></select></div></div>
<label>عنوان اختياري</label><input id="title" placeholder="عنوان الفيديو"><button class="btn" id="gb" onclick="generate()">إنشاء MP4</button><div class="status" id="gs"></div><div class="result" id="gr"></div></section>
<section id="edit" class="panel hidden"><h2>تعديل فيديو</h2><label>اختيار الفيديو</label><input type="file" id="video" accept="video/*"><div class="grid"><div><label>القص من ثانية</label><input id="start" type="number" min="0" value="0" step=".1"></div><div><label>القص إلى ثانية (0 للنهاية)</label><input id="end" type="number" min="0" value="0" step=".1"></div></div>
<div class="grid"><div><label>المقاس</label><select id="ea"><option value="keep">كما هو</option><option value="vertical">عمودي 9:16</option><option value="horizontal">أفقي 16:9</option></select></div><div><label>الصوت الأصلي</label><select id="mute"><option value="false">احتفظ به</option><option value="true">احذفه</option></select></div></div>
<button class="btn" id="eb" onclick="editVideo()">تعديل وتصدير MP4</button><div class="status" id="es"></div><div class="result" id="er"></div></section>
<p class="note">إذا كانت الخدمة المجانية نائمة، انتظر حتى تستيقظ. معالجة الفيديوهات الكبيرة قد تتجاوز موارد الاستضافة المجانية.</main>
<script>
function tab(id,b){document.querySelectorAll('section').forEach(x=>x.classList.add('hidden'));document.getElementById(id).classList.remove('hidden');document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active')}
function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function result(el,d){el.style.display='block';el.style.background=d.error?'#3b1c24':'#0d2b27';el.innerHTML=(d.error?'❌ '+esc(d.error):'✅ '+esc(d.message||'اكتمل')+'<br><a href="'+d.download+'" download>📥 تنزيل ملف MP4</a>')}
async function generate(){let p=document.getElementById('prompt').value.trim(),b=document.getElementById('gb'),s=document.getElementById('gs'),r=document.getElementById('gr');if(!p){s.textContent='اكتب وصف الفيديو أولاً';return}b.disabled=true;s.textContent='جاري تجهيز الفيديو...';try{let f=new FormData();f.append('prompt',p);f.append('duration',document.getElementById('duration').value);f.append('aspect',document.getElementById('aspect').value);f.append('title',document.getElementById('title').value);let d=await(await fetch('/api/generate',{method:'POST',body:f})).json();result(r,d);s.textContent=d.ok?'اكتمل':'تعذر التنفيذ'}catch(e){s.textContent='تعذر الاتصال بالخادم'}finally{b.disabled=false}}
async function editVideo(){let file=document.getElementById('video').files[0],b=document.getElementById('eb'),s=document.getElementById('es'),r=document.getElementById('er');if(!file){s.textContent='اختر فيديو أولاً';return}b.disabled=true;s.textContent='جاري معالجة الفيديو...';try{let f=new FormData();f.append('video',file);f.append('start',document.getElementById('start').value||'0');f.append('end',document.getElementById('end').value||'0');f.append('aspect',document.getElementById('ea').value);f.append('mute_original',document.getElementById('mute').value);let d=await(await fetch('/api/edit',{method:'POST',body:f})).json();result(r,d);s.textContent=d.ok?'اكتمل':'تعذر التنفيذ'}catch(e){s.textContent='تعذر الاتصال بالخادم'}finally{b.disabled=false}}
</script></body></html>"""

def ff(args):
    p = subprocess.run([FFMPEG, "-y"] + [str(x) for x in args], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode:
        raise RuntimeError((p.stderr or "FFmpeg error")[-1200:])

def font(size):
    for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf","/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf","C:/Windows/Fonts/arial.ttf"]:
        try: return ImageFont.truetype(p,size)
        except: pass
    return ImageFont.load_default()

def make_card(text, path, w, h):
    im=Image.new("RGB",(w,h),(14,20,32)); d=ImageDraw.Draw(im)
    d.rounded_rectangle((25,45,w-25,h-45),radius=24,outline=(89,225,191),width=3)
    f=font(42 if w<1000 else 46); words=text.split(); lines=[]; line=""
    for word in words:
        test=(line+" "+word).strip()
        if d.textbbox((0,0),test,font=f)[2] < w-90 or not line: line=test
        else: lines.append(line);line=word
    if line: lines.append(line)
    lines=lines[:8]; heights=[d.textbbox((0,0),x,font=f)[3] for x in lines]
    y=(h-(sum(heights)+15*max(0,len(lines)-1)))//2
    for line,hh in zip(lines,heights):
        box=d.textbbox((0,0),line,font=f); d.text(((w-(box[2]-box[0]))//2,y),line,font=f,fill=(245,247,250)); y+=hh+15
    d.text((w//2-145,h-95),"CENTILLION VIDEO STUDIO",font=font(20),fill=(89,225,191))
    im.save(path)

async def voice(text,path):
    try:
        import edge_tts
        await edge_tts.Communicate(text, "ar-EG-SalmaNeural").save(str(path))
        return path.exists() and path.stat().st_size>1000
    except Exception: return False

@app.get("/",response_class=HTMLResponse)
def home(): return HTML

@app.get("/health")
def health(): return {"ok":True}

@app.post("/api/generate")
async def generate(prompt:str=Form(...),duration:int=Form(20),aspect:str=Form("vertical"),title:str=Form("")):
    prompt=re.sub(r"\s+"," ",prompt).strip()[:1400]
    if not prompt:return JSONResponse({"error":"اكتب وصف الفيديو"},status_code=400)
    duration=max(5,min(60,int(duration))); w,h=(720,1280) if aspect=="vertical" else (1280,720)
    cards=[x.strip() for x in re.split(r"(?<=[.!؟])\s+",prompt) if x.strip()] or [prompt]
    cards=cards[:10]; sec=max(2,duration/len(cards)); paths=[]
    try:
        for i,txt in enumerate(cards):
            p=OUTPUT/f"{uuid.uuid4().hex}.png";make_card(txt,p,w,h);paths.append(p)
        concat=OUTPUT/f"{uuid.uuid4().hex}.txt";silent=OUTPUT/f"{uuid.uuid4().hex}_silent.mp4";out=OUTPUT/f"centillion_{uuid.uuid4().hex[:10]}.mp4";aud=OUTPUT/f"{uuid.uuid4().hex}.mp3"
        with open(concat,"w",encoding="utf-8") as f:
            for p in paths:f.write("file '"+str(p)+"'\n"+f"duration {sec:.3f}\n")
            f.write("file '"+str(paths[-1])+"'\n")
        ff(["-f","concat","-safe","0","-i",concat,"-vf",f"scale={w}:{h},format=yuv420p","-r","25","-c:v","libx264","-preset","ultrafast",silent])
        hasvoice=await voice(prompt,aud)
        if hasvoice: ff(["-stream_loop","-1","-i",silent,"-i",aud,"-t",duration+10,"-c:v","libx264","-preset","ultrafast","-c:a","aac","-shortest",out])
        else: ff(["-i",silent,"-t",duration,"-c:v","copy","-an",out])
        return {"ok":True,"download":f"/api/download/{out.name}","voice":hasvoice,"message":"تم إنشاء فيديو تصميمي MP4. المشاهد ليست توليداً سينمائياً واقعياً."+( " تم إنشاء تعليق صوتي." if hasvoice else " لم يتوفر التعليق الصوتي؛ الفيديو بلا صوت.")}
    except Exception as e:return JSONResponse({"error":"فشل إنشاء الفيديو: "+str(e)},status_code=500)
    finally:
        for p in locals().get("paths",[]):
            try:p.unlink(missing_ok=True)
            except:pass
        for key in ("concat","silent","aud"):
            p=locals().get(key)
            if p:
                try:p.unlink(missing_ok=True)
                except:pass

@app.post("/api/edit")
async def edit(video:UploadFile=File(...),start:float=Form(0),end:float=Form(0),aspect:str=Form("keep"),mute_original:bool=Form(False)):
    ext=Path(video.filename or "video.mp4").suffix.lower()
    if ext not in [".mp4",".mov",".mkv",".webm",".avi",".m4v"]:return JSONResponse({"error":"صيغة الفيديو غير مدعومة"},status_code=400)
    src=UPLOADS/f"{uuid.uuid4().hex}{ext}";out=OUTPUT/f"edited_{uuid.uuid4().hex[:10]}.mp4"
    try:
        with open(src,"wb") as f:
            while True:
                chunk=await video.read(1024*1024)
                if not chunk:break
                f.write(chunk)
        args=[]
        if start>0:args+=["-ss",start]
        args+=["-i",src]
        if end>start:args+=["-t",max(0.1,end-start)]
        if aspect=="vertical":args+=["-vf","scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2"]
        elif aspect=="horizontal":args+=["-vf","scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2"]
        if mute_original:args+=["-an"]
        else:args+=["-c:a","aac","-b:a","128k"]
        args+=["-c:v","libx264","-preset","ultrafast","-crf","25","-movflags","+faststart",out]
        ff(args)
        return {"ok":True,"download":f"/api/download/{out.name}","message":"تم قص/تحويل الفيديو إلى MP4."}
    except Exception as e:return JSONResponse({"error":"فشل تعديل الفيديو: "+str(e)},status_code=500)
    finally:
        try:src.unlink(missing_ok=True)
        except:pass

@app.get("/api/download/{name}")
def download(name:str):
    if Path(name).name!=name:return JSONResponse({"error":"اسم ملف غير صالح"},status_code=400)
    p=OUTPUT/name
    if not p.exists():return JSONResponse({"error":"الملف غير موجود أو انتهت صلاحيته"},status_code=404)
    return FileResponse(p,media_type="video/mp4",filename=name)
